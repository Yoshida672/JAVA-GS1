package Perfil;

public class Visitante {
    private String nome;
    private String idade;
}
