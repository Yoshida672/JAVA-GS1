package Perfil;

public class Telefone {
    private int DDD;
    private int DDI;
    private String numeroTelefone;
}
