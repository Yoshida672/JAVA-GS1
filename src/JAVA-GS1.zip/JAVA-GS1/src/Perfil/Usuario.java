package Perfil;

public class Usuario {
    private String nome;
    private String dataNascimento;
    private String cpf;
    private Telefone telefone;
}
