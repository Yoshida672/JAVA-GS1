package Perfil;

public class Supervisor extends Usuario{

}
