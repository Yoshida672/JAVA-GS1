package Captura;

public enum METODO_CAPTURA {
    REDE_ARRASTO,
    PALANGRE,
    CERCO,
    REDE_EMALHAR,
    COVO,
    DRAGA,
    VARA
}
