package Captura;

public class Especie {
    private String nomePopular;
    private String nomeCientifico;
    private double tamanhoMedio;
    private double pesoMedio;
    private String periodoReproducao;
    private NIVEL_EXTINCAO nivelExtincao;
}
