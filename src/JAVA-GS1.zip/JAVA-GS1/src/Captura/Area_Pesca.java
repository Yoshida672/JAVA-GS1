package Captura;

public class Area_Pesca {
    private String coordenada;
    private String especiesComuns;
    private double extensao;
    private ESTADO_CONSERVACAO estadoConservacao;
}
