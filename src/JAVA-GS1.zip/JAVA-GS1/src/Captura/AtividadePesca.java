package Captura;

public class AtividadePesca {
    private Especie especie;
    private int qtdEspecie;
    private Area_Pesca localizacao;
    private double pesoTotal;
    private METODO_CAPTURA metodo;

}
