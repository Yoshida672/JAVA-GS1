package Captura;

public enum NIVEL_EXTINCAO {
    EX,
    EW,
    CR,
    EN,
    VU,
    NT,
    LC,
    DD;
}
