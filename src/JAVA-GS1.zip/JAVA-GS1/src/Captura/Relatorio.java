package Captura;

public class Relatorio {
}
