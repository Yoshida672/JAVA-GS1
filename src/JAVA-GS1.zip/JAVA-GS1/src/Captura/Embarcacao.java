package Captura;

public class Embarcacao {
    private String nome;
    private String tipoEmbarcacao;
    private String registroMaritimo;

    private Porto portoOrigem;
    private String proprietario;
    private String statusLegal;
    private int numero_viagens;
    private int limite_viagens;
}
