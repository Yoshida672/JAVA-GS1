package Captura;

import Perfil.Endereco;

import java.time.LocalDate;

public class Porto {
    private String nomePorto;
    private Endereco endereco;
    private int qtdBercos;
    private double custoGeral;

}
