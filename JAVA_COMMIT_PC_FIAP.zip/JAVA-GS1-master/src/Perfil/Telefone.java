package Perfil;

public class Telefone {
    private int DDD;
    private int DDI;
    private String numeroTelefone;
    private String operadora;
    public Telefone() {
    }

    public Telefone(int DDD, int DDI, String numeroTelefone, String operadora) {
        this.DDD = DDD;
        this.DDI = DDI;
        this.numeroTelefone = numeroTelefone;
        this.operadora = operadora;
    }

    public int getDDD() {
        return DDD;
    }

    public void setDDD(int DDD) {
        this.DDD = DDD;
    }

    public int getDDI() {
        return DDI;
    }

    public void setDDI(int DDI) {
        this.DDI = DDI;
    }

    public String getNumeroTelefone() {
        return numeroTelefone;
    }

    public void setNumeroTelefone(String numeroTelefone) {
        this.numeroTelefone = numeroTelefone;
    }

    public String getOperadora() {
        return operadora;
    }

    public void setOperadora(String operadora) {
        this.operadora = operadora;
    }

    @Override
    public String toString() {
        return new StringBuilder()
                .append(getOperadora()+" ")
                .append("+"+getDDI())
                .append("("+getDDD()+")")
                .append(getNumeroTelefone()).toString();
    }
    public void verTelefone(){
        System.out.println(toString());
    }
}
