
import Captura.Especie;
import Captura.NIVEL_EXTINCAO;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
    adicionarEspecie();

    }

    public static void adicionarEspecie() {
        Scanner scanner = new Scanner(System.in);

        Especie especie = new Especie();

        System.out.println("Digite o nome popular da espécie:");
        String nomePopular = scanner.nextLine();
        while (contemNumeros(nomePopular) || nomePopular == "" ) {
            if (contemNumeros(nomePopular)){
                System.out.println("O nome popular não pode conter números. Por favor, tente novamente:");
            }
            if (nomePopular== ""){
                System.out.println("O campo não pode ficar vazio. Por favor, tente novamente:");
            }
            nomePopular = scanner.nextLine();
        }
        especie.setNomePopular(nomePopular);

        System.out.println("Digite o nome científico da espécie:");
        String nomeCientifico = scanner.nextLine();
        while (contemNumeros(nomeCientifico)|| nomeCientifico == "") {
            if (contemNumeros(nomeCientifico)){
                System.out.println("O nome científico não pode conter números. Por favor, tente novamente:");
            }
            if (nomeCientifico== ""){
                System.out.println("O campo não pode ficar vazio. Por favor, tente novamente:");
            }
            nomeCientifico = scanner.nextLine();
        }
        especie.setNomeCientifico(nomeCientifico);

        System.out.println("Digite o tamanho médio da espécie em centímetros:");
        double tamanhoMedio = scanner.nextDouble();
        while (tamanhoMedio <= 0) {
            System.out.println("O tamanho médio deve ser um valor positivo. Por favor, tente novamente:");
            tamanhoMedio = scanner.nextDouble();
        }
        especie.setTamanhoMedio(tamanhoMedio);

        System.out.println("Digite o peso médio da espécie em gramas:");
        double pesoMedio = scanner.nextDouble();
        while (pesoMedio <= 0) {
            System.out.println("O peso médio deve ser um valor positivo. Por favor, tente novamente:");
            pesoMedio = scanner.nextDouble();
        }
        especie.setPesoMedio(pesoMedio);

        scanner.nextLine();

        System.out.println("Digite o período de reprodução da espécie:");
        String periodoReproducao = scanner.nextLine();
        while (contemNumeros(periodoReproducao) || periodoReproducao=="") {
            if (contemNumeros(periodoReproducao)) {
                System.out.println("O período de reprodução não pode conter números. Por favor, tente novamente:");
            }
            if(periodoReproducao==""){
                System.out.println("O campo não pode ficar vazio. Por favor, tente novamente:");
            }
            periodoReproducao = scanner.nextLine();
        }
        especie.setPeriodoReproducao(periodoReproducao);

        boolean validNivelExtincao = false;
        while (!validNivelExtincao) {
            System.out.println("Digite o nível de extinção da espécie (CRITICAMENTE_EM_PERIGO, EM_PERIGO, VULNERAVEL, POUCO_PREOCUPANTE, NAO_AVALIADO):");
            String nivel = scanner.nextLine().toUpperCase().replace(" ","_");
            try {
                NIVEL_EXTINCAO nivelExtincao = NIVEL_EXTINCAO.valueOf(nivel);
                if (nivelExtincao == NIVEL_EXTINCAO.EXTINTO || nivelExtincao == NIVEL_EXTINCAO.EXTINTO_NA_NATUREZA) {
                    System.out.println("Espécie em nível de extinção EXTINTO ou EXTINTO NA NATUREZA. Não é possível adicionar.");
                } else {
                    especie.setNivelExtincao(nivelExtincao);
                    validNivelExtincao = true;
                }
            } catch (IllegalArgumentException e) {
                System.out.println("Nível de extinção inválido. Por favor, tente novamente.");
            }
        }
        especie.mostrarEspecie();
    }
    private static boolean contemNumeros(String s) {
        for (int i = 0; i < s.length(); i++) {
            if (Character.isDigit(s.charAt(i))) {
                return true;
            }
        }
        return false;
    }}