package Captura;

import java.util.ArrayList;

public class Relatorio {
    private ArrayList<RegistroPesca> registrosPesca;

    public Relatorio() {
    }

    public Relatorio(Inspecao inspecao, ArrayList<RegistroPesca> registrosPesca) {
        this.registrosPesca = registrosPesca;
    }
    public ArrayList<RegistroPesca> getRegistrosPesca() {
        return registrosPesca;
    }

    public void setRegistrosPesca(ArrayList<RegistroPesca> registrosPesca) {
        this.registrosPesca = registrosPesca;
    }

    @Override
    public String toString() {
        return "Relatorio{" +
                ", registrosPesca=" + registrosPesca +
                '}';
    }
}
