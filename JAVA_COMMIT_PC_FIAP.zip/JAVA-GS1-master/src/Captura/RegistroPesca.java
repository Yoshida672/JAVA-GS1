package Captura;

public class RegistroPesca {
    private Embarcacao embarcacao;
    private METODO_CAPTURA metodoCaptura;
    private Especie especie;
    private AreaPesca locaisPesca;
    private double pesoTotal;
    public int quantidade;

    public RegistroPesca() {
    }

    public RegistroPesca(Embarcacao embarcacao, METODO_CAPTURA metodoCaptura, Especie especie, AreaPesca locaisPesca, double pesoTotal) {
        this.embarcacao = embarcacao;
        this.metodoCaptura = metodoCaptura;
        this.especie = especie;
        this.locaisPesca = locaisPesca;
        this.pesoTotal = pesoTotal;
    }

    public Embarcacao getEmbarcacao() {
        return embarcacao;
    }

    public void setEmbarcacao(Embarcacao embarcacao) {
        this.embarcacao = embarcacao;
    }

    public METODO_CAPTURA getMetodoCaptura() {
        return metodoCaptura;
    }

    public void setMetodoCaptura(METODO_CAPTURA metodoCaptura) {
        this.metodoCaptura = metodoCaptura;
    }

    public Especie getEspecie() {
        return especie;
    }

    public void setEspecie(Especie especie) {
        this.especie = especie;
    }

    public AreaPesca getLocaisPesca() {
        return locaisPesca;
    }

    public void setLocaisPesca(AreaPesca locaisPesca) {
        this.locaisPesca = locaisPesca;
    }

    public double getPesoTotal() {
        return pesoTotal;
    }

    public void setPesoTotal(double pesoTotal) {
        this.pesoTotal = pesoTotal;
    }

    @Override
    public String toString() {
        return "RegistroPesca{" +
                "embarcacao=" + embarcacao +
                ", metodoCaptura=" + metodoCaptura +
                ", especie=" + especie +
                ", locaisPesca=" + locaisPesca +
                ", pesoTotal=" + pesoTotal +
                '}';
    }

    public void calcularQuantidade(Especie especie){
    quantidade = (int) (pesoTotal / especie.getPesoMedio());
    }
    public int verQuantidade(){

        return quantidade;
    }
}
