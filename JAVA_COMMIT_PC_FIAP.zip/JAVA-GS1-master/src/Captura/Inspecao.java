package Captura;

import Perfil.Supervisor;

import java.util.ArrayList;
import java.util.Date;

public class Inspecao {
    private Date data;
    private Porto porto;
    private ArrayList<Embarcacao> embarcacoes;
    private Supervisor supervisor;
    private RegistroPesca registroPesca;

    public Inspecao() {
    }

    public Inspecao(Date data, Porto porto, ArrayList<Embarcacao> embarcacoes, Supervisor supervisor, RegistroPesca registroPesca) {
        this.data = data;
        this.porto = porto;
        this.embarcacoes = embarcacoes;
        this.supervisor = supervisor;
        this.registroPesca = registroPesca;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public Porto getPorto() {
        return porto;
    }

    public void setPorto(Porto porto) {
        this.porto = porto;
    }

    public ArrayList<Embarcacao> getEmbarcacoes() {
        return embarcacoes;
    }

    public void setEmbarcacoes(ArrayList<Embarcacao> embarcacoes) {
        this.embarcacoes = embarcacoes;
    }

    public Supervisor getSupervisor() {
        return supervisor;
    }

    public void setSupervisor(Supervisor supervisor) {
        this.supervisor = supervisor;
    }

    public RegistroPesca getRegistroPesca() {
        return registroPesca;
    }

    public void setRegistroPesca(RegistroPesca registroPesca) {
        this.registroPesca = registroPesca;
    }

    public void registrarInspecao() {
        // Código para registrar inspeção
        System.out.println("Inspeção registrada no porto: " + porto.getNomePorto() + " na data: " + data);
    }
}


